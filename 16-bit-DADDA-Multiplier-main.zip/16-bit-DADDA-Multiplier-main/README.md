# 16-bit-DADDA-Multiplier
16-bit DADDA Multiplier design using using 5:2 compressor as the major reduction compressor and 4:2 compressor; FullAdder and HalfAdder to simulate 3:2 and 2:2 compressors respectively.

# Usage
```iverilog dadda_tb.v```

# Output
-Test Bench
<img width="1577" alt="TestBenchOutput" src="https://user-images.githubusercontent.com/60811574/118267724-24e83500-b4da-11eb-89ca-50dcffe52e1d.png">

-GTK Waveform
<img width="1577" alt="GTKWave" src="https://user-images.githubusercontent.com/60811574/118267761-32052400-b4da-11eb-98fe-f5b31205ad57.png">
