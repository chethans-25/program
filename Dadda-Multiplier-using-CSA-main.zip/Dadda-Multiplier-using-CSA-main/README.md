# Dadda-Multiplier (VLSI for signal processing)
Dadda multipliers require less area and are slightly faster than Wallace tree multipliers. 
Among tree multipliers, Dadda multiplier is the most popular multiplier.
The above code consists of (8,8), (16,16), (32,32) dadda multiplier along with self checking test bench.
